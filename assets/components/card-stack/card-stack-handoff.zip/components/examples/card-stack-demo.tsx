"use client";

import CardStack, { type CardStackItem } from "@/components/ui/card-stack";

/**
 * CardStack demo.
 *
 * Images are intentionally left unset (no imageSrc) — the component renders a
 * grey placeholder #D4D4D4 as per the design. To show real photos, add an
 * `imageSrc` field to the array items.
 */

const items: CardStackItem[] = [
  {
    id: "terrazza-rame",
    title: "Terrazza Ramè Experience",
    tags: ["Restaurant", "Mediterranean", "Italian"],
  },
  {
    id: "sakura-lounge",
    title: "Sakura Lounge & Bar",
    tags: ["Bar", "Japanese", "Cocktails"],
  },
  {
    id: "le-petit-jardin",
    title: "Le Petit Jardin",
    tags: ["Café", "French", "Bakery"],
  },
  {
    id: "nordic-smokehouse",
    title: "Nordic Smokehouse",
    tags: ["Grill", "Scandinavian", "BBQ"],
  },
  {
    id: "casa-del-sol",
    title: "Casa del Sol",
    tags: ["Tapas", "Spanish", "Wine"],
  },
];

export default function DemoOne() {
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#DCE6F5",
      }}
    >
      <CardStack items={items} intervalMs={3500} />
    </div>
  );
}
